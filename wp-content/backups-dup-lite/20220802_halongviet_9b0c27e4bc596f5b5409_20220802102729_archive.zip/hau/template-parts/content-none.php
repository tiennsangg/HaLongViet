<?php

/**
 * Template part for displaying a message that posts cannot be found
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package hazo
 */

?>

<p class="hazo-no_post_found"><?php _e('Chưa có bài viết nào được đăng.', 'hazo'); ?></p>